import React, {
    useState
} from "react";

const WORDS = ["apple", "grape", "table", "chair", "plant"];
const TARGET_WORD = WORDS[Math.floor(Math.random() * WORDS.length)];
const MAX_ATTEMPTS = 6;

const getFeedback = (guess, target) => {
    return guess.split("").map((char, i) => {
        if (char === target[i]) return "green";
        if (target.includes(char)) return "yellow";
        return "gray";
    });
};

const Wordle = () => {
    const [guesses, setGuesses] = useState([]);
    const [input, setInput] = useState("");
    const [status, setStatus] = useState("playing");

    const handleGuess = () => {
        if (input.length !== 5 || guesses.length >= MAX_ATTEMPTS) return;
        const newGuesses = [...guesses, {
            word: input,
            feedback: getFeedback(input, TARGET_WORD)
        }];
        setGuesses(newGuesses);
        setInput("");
        if (input === TARGET_WORD) setStatus("won");
        if (newGuesses.length >= MAX_ATTEMPTS && input !== TARGET_WORD) setStatus("lost");
    };

    const resetGame = () => {
        window.location.reload();
    };

    return ( <
        div className = "game-container"
        style = {
            {
                textAlign: "center",
                fontFamily: "Arial, sans-serif"
            }
        } >
        <
        h1 > Wordle Clone < /h1> <
        div className = "grid"
        style = {
            {
                display: "inline-block"
            }
        } > {
            guesses.map(({
                word,
                feedback
            }, index) => ( <
                div key = {
                    index
                }
                className = "row"
                style = {
                    {
                        display: "flex",
                        justifyContent: "center",
                        marginBottom: "5px"
                    }
                } > {
                    word.split("").map((char, i) => ( <
                        span key = {
                            i
                        }
                        style = {
                            {
                                display: "inline-block",
                                width: "40px",
                                height: "40px",
                                lineHeight: "40px",
                                textAlign: "center",
                                border: "1px solid black",
                                margin: "2px",
                                backgroundColor: feedback[i],
                                color: "white",
                                fontSize: "20px"
                            }
                        } > {
                            char
                        } < /span>
                    ))
                } <
                /div>
            ))
        } <
        /div> {
            status === "playing" ? ( <
                >
                <
                input type = "text"
                value = {
                    input
                }
                onChange = {
                    (e) => setInput(e.target.value.toLowerCase())
                }
                maxLength = "5"
                style = {
                    {
                        padding: "5px",
                        fontSize: "16px"
                    }
                }
                /> <
                button onClick = {
                    handleGuess
                }
                style = {
                    {
                        marginLeft: "10px",
                        padding: "5px",
                        fontSize: "16px"
                    }
                } > Submit < /button> <
                />
            ) : ( <
                h2 > {
                    status === "won" ? "You Won!" : "Game Over!"
                } < /h2>
            )
        } <
        button onClick = {
            resetGame
        }
        style = {
            {
                display: "block",
                margin: "10px auto",
                padding: "5px",
                fontSize: "16px"
            }
        } > New Game < /button> <
        /div>
    );
};

export default Wordle;